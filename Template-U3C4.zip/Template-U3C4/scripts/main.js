async function apiCall(url) {


    //add api call logic here
    // let url = "https://shrouded-earth-23381.herokuapp.com/api/headlines/india";

    try {

      let res = await fetch(url);

      let data = await res.json();


      console.log(data);

     return (data);

    //   appendData(data);

    }
    catch (err) {
      console.log(err);
    }

}


function appendArticles(articles, main) {

    //add append logic here

    articles.forEach(function (el) {


        let div = document.createElement("div");
        div.setAttribute("id", "index-div");
        div.addEventListener("click",function (){
          newsShow(el);
        })
  
        let img = document.createElement("img");
        img.setAttribute("id", "index-img");
        img.src = el.urlToImage;
  
  
        let title = document.createElement("p");
        title.setAttribute("id", "index-title");
        title.innerText = el.title;
  
        div.append(img, title);
  
        main.append(div);
  
      });

}

export { apiCall, appendArticles }