function sidebar() {


    // return your html component here
    //Make sure to give input search box id as ""

    return ` <h1>Times of India</h1>
    <div id="flex-tag">
      <p>Home</p>
      <p>Login</p>
      <p>SignUp</p>
      <p>Settings</p>
    </div>

    <input type="text" id="input" placeholder="search news here">
    <button id="search-button" onclick="searchData()">Search</button>
    <div id="show-search"></div>`;
}
export default sidebar